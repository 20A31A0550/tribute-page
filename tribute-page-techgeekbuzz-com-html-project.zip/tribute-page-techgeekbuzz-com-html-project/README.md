# Tribute Page(techgeekbuzz.com html project)

A Pen created on CodePen.io. Original URL: [https://codepen.io/vinay-khatri/pen/jOzjodR](https://codepen.io/vinay-khatri/pen/jOzjodR).

